
  <?php $__env->startSection('content'); ?>
  <form method="POST" action="<?php echo e(route('user.update', $User->id)); ?>"  role="form" enctype="multipart/form-data">
    <?php echo e(method_field('PATCH')); ?>

    <?php echo csrf_field(); ?>
      <div class="form-group">
        <label">Name</label>
        <input type="text" class="form-control" name="name" value="<?php echo e($User->name); ?>">
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Email address</label>
        <input type="email" class="form-control" id="exampleInputEmail1" name="email" value="<?php echo e($User->email); ?>">
        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
      </div>
      <div class="form-group">
        <label for="sel1">Select list:</label>
        <select class="form-control" name="status">
          <?php echo e($status = $User->status); ?>

          <?php if(!empty($status)): ?>
            <option value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
          <?php else: ?>
            <option value="">-- Select one --</option>
          <?php endif; ?>
          <option value="Admin">Admin</option>
          <option value="User">User</option>
        </select>
      </div>
      <!-- <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password">
      </div> -->
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rekin\Documents\GitHub\wedding\resources\views/user/edit.blade.php ENDPATH**/ ?>