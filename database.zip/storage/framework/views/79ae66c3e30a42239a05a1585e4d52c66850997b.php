
<?php $__env->startSection('content'); ?>
<div>
  <a href="<?php echo e(route('user.create')); ?>" class="btn btn-lg btn-primary">
    <i class="fa fa-plus" style="color:white"></i>
  </a>
</div>
<br>
<table id="example" class="table">
  <thead>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($item->name); ?></td>
        <td><?php echo e($item->email); ?></td>
        <td><?php echo e($item->status); ?></td>
        <td> 
          <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('user.destroy', $item->id)); ?>" method="POST">
            <a href="<?php echo e(route('user.edit', Crypt::encrypt($item->id))); ?>" class="btn btn-sm btn-primary">
              <i class="fa fa-edit" style="color:white"></i>
            </a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>   
            <button type="submit" class="btn btn-sm btn-danger">
              <i class="fa fa-trash" style="color:white"></i>
            </button>
          </form> 
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rekin\Documents\GitHub\wedding\resources\views/user/index.blade.php ENDPATH**/ ?>