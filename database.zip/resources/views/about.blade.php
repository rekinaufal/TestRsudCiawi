@extends('layouts.main')
@section('content')
        <h1>Hello, about!</h1>
@endsection